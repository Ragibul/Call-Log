package com.androidexample.calllog;

public class VariableValues {
	
	public static int Search = 1;
	public static String IMEI = null;
	public static String type = "";
	public static String PhoneNumber = "";
	
} 